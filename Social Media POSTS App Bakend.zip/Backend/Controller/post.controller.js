const mongoose = require("mongoose");
const Post = require("../Model/post.model");
const { response } = require("express");

async function createpost(req, res) {
  let { title, content } = req.body;
  let userid = req.user.id;
  console.log(userid);
  let data = await Post.create({ title, content, user: userid });
  //   console.log(data);
  res.status(200).json({ status: true, response: "Done" });
}

async function allpost(req, res) {
  let allposts = await Post.find({}).populate("user", "firstname lastname");
  res.status(200).json({ status: true, response: "All Users Posts", allposts });
}

async function deletepost(req, res) {
  try {
    let postid = req.params.id;
    let userid = req.user.id;
    console.log(userid, "userid", postid, "postid");

    const post = await Post.findById(postid);
    if (!post) {
      return res
        .status(404)
        .json({ status: false, response: "Post not Found" });
    }

    if (post.user.toString() !== userid) {
      // Convert ObjectId to string for comparison
      return res.status(403).json({
        status: false,
        response: "You are not authorized to delete this post",
      });
    }

    await Post.deleteOne({ _id: postid }); // Correct the delete query
    return res
      .status(200)
      .json({ status: true, response: "Post deleted successfully" });
  } catch (error) {
    console.error("Error deleting post:", error);
    return res
      .status(500)
      .json({ status: false, response: "Internal Server Error" });
  }
}

async function updatepost(req, res) {
  try {
    let postid = req.params.id;
    let userid = req.user.id;
    let { title, content } = req.body;
    console.log(userid, "userid", postid, "postid");

    const post = await Post.findById(postid);
    if (!post) {
      return res
        .status(404)
        .json({ status: false, response: "Post not Found" });
    }

    if (post.user.toString() !== userid) {
      return res.status(403).json({
        status: false,
        response: "You are not authorized to update this post",
      });
    }

    if (title) post.title = title;
    if (content) post.content = content;

    await post.save();

    return res
      .status(200)
      .json({ status: true, response: "Post updated successfully" });
  } catch (error) {
    console.error("Error updating post:", error);
    return res
      .status(500)
      .json({ status: false, response: "Internal Server Error" });
  }
}

module.exports = {
  allpost,
  createpost,
  deletepost,
  updatepost,
};
