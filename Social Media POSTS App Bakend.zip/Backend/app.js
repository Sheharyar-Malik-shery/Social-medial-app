require("dotenv").config();
const express = require("express");
const connectDB = require("./Connection/db");
const cors = require("cors");
const app = express();
var cookieParser = require("cookie-parser");

const userRoutes = require("./Routes/User");
const postrouter = require("./Routes/post.rouer");
var corsOptions = {
  origin: ["http://localhost:5173"],
  credentials: true,
};
// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors(corsOptions));
app.use(cookieParser());

// Middleware to parse URL-encoded bodies (form data)
app.use(express.urlencoded({ extended: true }));
connectDB();
// Import the user routes

// Use the user routes
app.use("/user", userRoutes);
app.use("/post", postrouter);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
