const express = require("express");
const router = express.Router();
const {
  allpost,
  createpost,
  deletepost,
  updatepost,
} = require("../Controller/post.controller");
const authorization = require("../middleware/auth");

router.post("/newpost", authorization, createpost);

router.get("/allpost", allpost);

router.delete("/deletepost/:id", authorization, deletepost);

router.patch("/updatepost/:id", authorization, updatepost);

module.exports = router;
